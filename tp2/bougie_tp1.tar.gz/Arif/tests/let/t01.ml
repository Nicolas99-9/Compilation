print_int 1 ;;
print_newline () ;;

(* Lecture d'une variable globale. *)
let a = 1 ;;
print_int a ;;
