print_int 5 ;;
print_newline () ;;

(* Addition, soustraction, associativité. *)
print_int (1 + 2 - 4 + 6) ;;
