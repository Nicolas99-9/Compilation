print_int 2 ;;
print_newline () ;;

(* Création d'une variable locale. *)
let x = 1 in print_int 2 ;;
