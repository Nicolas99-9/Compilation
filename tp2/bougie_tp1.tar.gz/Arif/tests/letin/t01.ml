print_int 4 ;;
print_newline () ;;

(* Création et lecture d'une variable locale. *)
let x = 4 in print_int x ;;
