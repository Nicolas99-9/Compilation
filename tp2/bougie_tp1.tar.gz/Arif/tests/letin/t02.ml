print_int 7 ;;
print_newline () ;;

(* Création et lecture de plusieurs variables locales. *)
let x = 4 in 
let y = 7 in
let z = 12 in
print_int y ;;
