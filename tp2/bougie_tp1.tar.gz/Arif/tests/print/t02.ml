print_int 6 ;;
print_newline () ;;

(* Vérification de la prise en compte des parenthèses *)
print_int (6) ;;
