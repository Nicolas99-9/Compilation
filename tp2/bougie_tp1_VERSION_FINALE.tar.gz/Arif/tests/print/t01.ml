print_int 4 ;;
print_newline () ;;
(* Vérification aussi des commentaires *)

print_int 4 ;;
