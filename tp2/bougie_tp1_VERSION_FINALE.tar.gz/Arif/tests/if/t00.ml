print_int 58 ;;
print_newline() ;;

(* If et constantes booléennes. *)
if true then print_int 5 else print_int 3 ;;
if false then print_int 4 else print_int 8 ;;
