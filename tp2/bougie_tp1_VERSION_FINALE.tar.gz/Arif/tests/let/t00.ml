print_int 0 ;;
print_newline () ;;

(* Allocation d'une variable globale. *)
let a = 1 ;;
print_int 0 ;;
