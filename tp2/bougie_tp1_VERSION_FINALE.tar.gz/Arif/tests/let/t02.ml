print_int 491 ;;
print_newline () ;;

(* Allocation et lecture de plusieurs variables globales. *)
let a = 1 ;;
let b = 4 ;;
let c = 9 ;;
print_int b ;;
print_int c ;;
print_int a ;;
