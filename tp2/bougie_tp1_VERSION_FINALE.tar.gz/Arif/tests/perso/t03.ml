print_int 18320876125 ;;
print_newline () ;;

(* Allocation et lecture de plusieurs variables globales. *)
let a = 125 ;;
let b = a+42 ;;
let c = a*b ;;
print_int (b+16);
print_int (c+1) ;;
print_int (1 * a) ;;
