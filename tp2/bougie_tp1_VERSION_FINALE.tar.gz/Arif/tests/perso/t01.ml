print_int 26356;;
print_newline () ;;
(* Arithmétique, la totale. *)
print_int (12 / 5 + 3 *(2+6)) ;;
print_int (125  * 3 + (12/6) * 2  -23) ;;

