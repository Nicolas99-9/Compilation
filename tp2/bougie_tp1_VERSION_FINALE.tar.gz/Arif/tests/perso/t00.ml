print_newline () ;;
print_int 22;;



(* Allocation et lecture de plusieurs variables globales. *)
let a = 12 ;;
let b = a - 2 ;;
let c = b + a ;;
print_newline () ;;
print_int c ;;
