print_int 7253 ;;
print_newline () ;;

(* Variables locales emboîtées. *)
let z = let x = (12 + 3)/2
	in let w = (x / 2) +145 in let q =  ((x*w*x) + 1)
in
print_int q;;
