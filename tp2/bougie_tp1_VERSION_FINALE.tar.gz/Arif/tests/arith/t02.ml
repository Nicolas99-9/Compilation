print_int (-6) ;;
print_newline () ;;

(* Addition, soustraction, parenthésage, nombres négatifs. *)
print_int (1 + 2 - (4 + 5)) ;;
